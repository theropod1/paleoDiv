
paleoDiv v0.0.7.0 (Release date: 2024-03-01)
==============

* Improved error-handling behaviour of pdb() function and others based on it

paleoDiv v0.0.6.0 (Release date: 2024-03-01)
==============

Changes:
* txt.y argument of phylo.spindles() now accepts vectorized input



paleoDiv v0.0.5.0 (Release date: 2024-02-29)
==============

Changes:
* First version of this package
 



