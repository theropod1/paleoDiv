# paleoDiv 0.2.0 (Release date: 2024-03-05)
==============

* fixed description, documentation and message output
* improved behavior of phylo.spindles in terms; now allows plotting without a phylogeny

# paleoDiv 0.1.1 (Release date: 2024-03-02)
==============

* improvement to the behavior of tree.ages() if data is not found and added option for occ.cleanup() to return whole data.frame instead of mere collumn

# paleoDiv v0.1.0 (Release date: 2024-03-01)
==============

* Additional function synonymize() that helps with manual editing of taxon-range tables to remove taxonomic errors


# paleoDiv v0.0.7 (Release date: 2024-03-01)
==============

* Improved error-handling behaviour of pdb() function and others based on it

# paleoDiv v0.0.6 (Release date: 2024-03-01)
==============

Changes:
* txt.y argument of phylo.spindles() now accepts vectorized input



# paleoDiv v0.0.5 (Release date: 2024-02-29)
==============

Changes:
* First version of this package
 



