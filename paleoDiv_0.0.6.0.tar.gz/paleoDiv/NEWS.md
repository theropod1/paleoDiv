paleoDiv v0.0.6.0 (Release date: 2024-03-01)
==============

Changes:
* txt.y argument of phylo.spindles() now accepts vectorized input



paleoDiv v0.0.5.0 (Release date: 2024-02-29)
==============

Changes:
* First version of this package
 



